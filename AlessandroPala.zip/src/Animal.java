public abstract class Animal {
    int age;
    String name;

    public abstract void makeNoise();

    public abstract void Color();

    public abstract void Movement();

}