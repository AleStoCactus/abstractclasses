public class PanzerSelbstfahrlafetteIfür  extends Animal {
    @Override

    public void makeNoise() {
        System.out.println("Panzer: BUM BUM BUM");
    }
    public void Movement() {
        System.out.println("Panzer: Ruota");
    }
    public void Color() {
        System.out.println("Panzer: Giallo");
    }
}
