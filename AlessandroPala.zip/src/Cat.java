public class Cat extends Animal {
    @Override

    public void makeNoise() {
        System.out.println("Gatto: Miao");
    }
    public void Movement() {
        System.out.println("Gatto: Gattona");
    }
    public void Color() {
        System.out.println("Gatto: Grigio");
    }

}
