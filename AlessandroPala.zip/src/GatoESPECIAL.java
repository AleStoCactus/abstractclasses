public class GatoESPECIAL extends Animal{
    @Override

    public void makeNoise() {
        System.out.println("GatoESPECIAL: MIAOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO");
    }
    public void Movement() {
        System.out.println("GatoESPECIAL: Corre e Salta");
    }
    public void Color() {
        System.out.println("GatoESPECIAL: GIALLO");
    }

}