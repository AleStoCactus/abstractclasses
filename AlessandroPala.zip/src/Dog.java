public class Dog extends Animal{
    @Override

    public void makeNoise() {
        System.out.println("Cane: Woof");
    }
    public void Movement() {
        System.out.println("Cane: Corre e Salta");
    }
    public void Color() {
        System.out.println("Cane: robe");
    }

}
